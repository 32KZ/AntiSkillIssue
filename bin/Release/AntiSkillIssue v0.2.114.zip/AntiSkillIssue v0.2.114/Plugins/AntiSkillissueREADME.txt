Hello!
32kz here.

Couple things to make sure you are testing correctly.

Please make sure you are running Beat Saber 1.25.0 or greater.
Please make sure you have BeatSaviorData intalled with a version of 2.1.14 or later. (BSD latest release as of time of writing Readme.txt: https://github.com/Mystogan98/BeatSaviorData/releases/tag/2.1.15 )


if you run the game and try open AntiSkillIssue, and it does not work, please capture the --Verbose responce and Errors in purple.
if you ever get an Access Denied error in the --verbose console, please Share it, and restart the game.

